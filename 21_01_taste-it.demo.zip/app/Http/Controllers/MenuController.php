<?php


namespace App\Http\Controllers;


class MenuController extends Controller
{

}
