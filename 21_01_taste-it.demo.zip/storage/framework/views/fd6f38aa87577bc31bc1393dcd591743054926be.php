<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Барча Овкатлар</span>
                        <a href="<?php echo e(route('admin.foods.index')); ?>" class="btn btn-success"> Ортга</a>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.foods.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="">Nomi</label>
                                <input type="text" class="form-control my-2" name="name" required>
                            </div>
                            <div class="form-group">
                                <label for="">Kategoriyasi</label>
                                <select type="text" class="form-select" name="category_id">
                                    <option value="">Tanlang</option>
                                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <option value=""> Tanlash uchun kategoriyalar yoq</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="">Narxi</label>
                                <input type="number" class="form-control my-2" name="price">
                            </div>
                            <div class="form-group">
                                <label for="">Retsepti</label>
                                <input type="text" class="form-control my-2" name="recept">
                            </div>
                            <div class="form-group">
                                <label for="">Rasmi</label>
                                <input type="file" class="form-control my-2" name="image">
                            </div>
                            <button type="submit" class="btn btn-primary mt-4 col-4 offset-8">Yaratish</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\taste-it.demo\resources\views/admin/food/create.blade.php ENDPATH**/ ?>