<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Барча Овкатлар</span>
                        <a href="<?php echo e(route('admin.foods.create')); ?>" class="btn btn-success"> Янги Яратиш</a>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-dark">
                            <tr>
                                <th scope="col">#ID</th>
                                <th scope="col">Nomi</th>
                                <th scope="col">Kategoriya</th>
                                <th scope="col">Narxi</th>
                                <th scope="col">Rasmi</th>
                                <th scope="col">Amaliyotlar</th>
                            </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $foods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($item->id); ?></th>
                                        <td><?php echo e($item->name); ?></td>
                                        <td>


                                            <?php echo e($item->category->id . ". " .$item->category->name); ?>

                                        </td>
                                        <td><?php echo e($item->price); ?> $</td>
                                        <td>
                                            <img src="<?php echo e($item->image); ?>" style="width: 150px;">
                                        </td>
                                        <td>
                                            <div class="d-flex justify-content-around">
                                                <a href="<?php echo e(route('admin.foods.edit', $item->id)); ?>" class="btn btn-primary">O`zgartirish</a>
                                                <form action="<?php echo e(route('admin.foods.destroy', $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-danger">O`chirish</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php echo e($foods->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\taste-it.demo\resources\views/admin/food/index.blade.php ENDPATH**/ ?>