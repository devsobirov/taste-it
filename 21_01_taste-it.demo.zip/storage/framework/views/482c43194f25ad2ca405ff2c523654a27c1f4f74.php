
<?php if($errors = \Illuminate\Support\Facades\Session::get('errors')): ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
    <?php $__currentLoopData = $errors->messages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $error; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger alert-dismissible fade show d-flex justify-content-between align-items-start" role="alert">
                <p><?php echo e($message); ?></p>
                <button type="button" class="close border-0 bg-transparent" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if($message = Session::get('msg')): ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="alert alert-danger alert-dismissible fade show d-flex justify-content-between align-items-start" role="alert">
                    <strong><?php echo e($message); ?></strong>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">

                    </button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="alert alert-success alert-dismissible fade show d-flex justify-content-between align-items-start" role="alert">
                    <strong><?php echo e($message); ?></strong>
                    <button type="button" class="close bg-transparent border-0" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php /**PATH D:\OpenServer\domains\taste-it.demo\resources\views/includes/messages.blade.php ENDPATH**/ ?>