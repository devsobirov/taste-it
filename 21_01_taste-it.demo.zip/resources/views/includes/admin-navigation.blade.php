

<li class="px-2 p-1">
    <a class="btn btn-secondary" href="{{ route('admin.categories.index') }}">
        Menu kategoriyalari
    </a>
</li>
<li class="px-2 p-1">
    <a class="btn btn-secondary" href="{{ route('admin.foods.index') }}">
        Menu taomlari
    </a>
</li>
