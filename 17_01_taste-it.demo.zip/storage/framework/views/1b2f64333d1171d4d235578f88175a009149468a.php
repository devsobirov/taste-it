

<li class="px-2 p-1">
    <a class="btn btn-secondary" href="<?php echo e(route('admin.categories.index')); ?>">
        Menu kategoriyalari
    </a>
</li>
<li class="px-2 p-1">
    <a class="btn btn-secondary" href="<?php echo e(route('admin.foods.index')); ?>">
        Menu taomlari
    </a>
</li>
<?php /**PATH D:\OpenServer\domains\taste-it.demo\resources\views/includes/admin-navigation.blade.php ENDPATH**/ ?>