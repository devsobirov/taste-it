<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Барча Меню категориялари</span>
                        <!-- <a href="/admin/categories/create" class="btn btn-success"> Янги Яратиш</a> -->
                        <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-success"> Янги Яратиш</a>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead class="thead-dark">
                            <tr>
                                <th scope="col">#ID</th>
                                <th scope="col">Nomi</th>
                                <th scope="col">Izoh</th>
                                <th scope="col">Amaliyotlar</th>
                            </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($item->id); ?></th>
                                        <td><?php echo e($item->word); ?> <?php echo e($item->niceName()); ?></td>
                                        <td><?php echo e($item->description); ?></td>
                                        <td>
                                            <div class="d-flex flex-column align-items-center justify-content-center">
                                                <a href="<?php echo e(route('admin.categories.edit', $item->id)); ?>" class="btn btn-success">Tahrirlash</a>
                                                <form action="<?php echo e(route('admin.categories.destroy', $item->id)); ?>" method="POST" class="my-2">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-danger">O'chirish</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php echo e($categories->links()); ?>, Jami: <?php echo e($categories->total()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\taste-it.demo\resources\views/admin/category/index.blade.php ENDPATH**/ ?>