<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>Барча Меню категориялари</span>
                        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline-success"> Барча категориялар</a>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.categories.update', $item->id)); ?>" method="POST">
                            <?php echo method_field('PATCH'); ?> <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Nomi</label>
                                <input class="form-control" value="<?php echo e($item->name); ?>" name="name">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Izoh</label>
                                <textarea name="description" id="" cols="30" rows="10" class="form-control"><?php echo e($item->description); ?></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary mt-4">Saqlash</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\taste-it.demo\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>