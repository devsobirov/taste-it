<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    public $word ='Hello';

    use HasFactory;

    protected $fillable = ['name', 'description'];
    //protected $guarded = [];

    protected $perPage = 15;


    //protected $table = 'categories'

    //Food -> Model , create_foods_table

    public function niceName()
    {
        return strtoupper($this->name);
    }

}
